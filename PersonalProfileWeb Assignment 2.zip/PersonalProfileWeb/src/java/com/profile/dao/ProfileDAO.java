package com.profile.dao;

import com.profile.model.ProfileBean;
import com.profile.util.DatabaseUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProfileDAO {
    
    private static boolean tableInitialized = false;
    
    private synchronized void initializeTable() {
        if (tableInitialized) {
            return;
        }
        
        Connection conn = null;
        Statement stmt = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            stmt = conn.createStatement();
       
            try {
                System.out.println("Initializing PROFILE table...");
                String createTableSQL = 
                    "CREATE TABLE PROFILE (" +
                    "ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1) PRIMARY KEY, " +
                    "NAME VARCHAR(255) NOT NULL, " +
                    "STUDENT_ID VARCHAR(50) NOT NULL UNIQUE, " +
                    "PROGRAM VARCHAR(255), " +
                    "EMAIL VARCHAR(255), " +
                    "HOBBIES CLOB, " +
                    "INTRODUCTION CLOB, " +
                    "PHOTO_FILE_NAME VARCHAR(255), " +
                    "CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                    "UPDATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                    ")";
                
                stmt.executeUpdate(createTableSQL);

                try {
                    stmt.executeUpdate("CREATE INDEX idx_student_id ON PROFILE(STUDENT_ID)");
                } catch (SQLException e) {
                }
                try {
                    stmt.executeUpdate("CREATE INDEX idx_name ON PROFILE(NAME)");
                } catch (SQLException e) {
                }
                try {
                    stmt.executeUpdate("CREATE INDEX idx_program ON PROFILE(PROGRAM)");
                } catch (SQLException e) {
                }
                
                System.out.println("✓ PROFILE table created successfully!");
                tableInitialized = true;
            } catch (SQLException createException) {
                if (createException.getErrorCode() == 30000 || 
                    createException.getSQLState().equals("X0Y32") ||
                    createException.getMessage().contains("already exists")) {
                    System.out.println("✓ PROFILE table already exists.");
                    tableInitialized = true;
                } else {
                    throw createException;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("✗✗✗ Error initializing PROFILE table:");
            System.err.println("SQL State: " + e.getSQLState());
            System.err.println("Error Code: " + e.getErrorCode());
            System.err.println("Message: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) DatabaseUtil.closeConnection(conn);
            } catch (SQLException e) {
                System.err.println("Error closing resources in initializeTable: " + e.getMessage());
            }
        }
    }

    public int insertProfile(ProfileBean profile) {
        initializeTable();
        
        String sql = "INSERT INTO PROFILE (NAME, STUDENT_ID, PROGRAM, EMAIL, HOBBIES, INTRODUCTION, PHOTO_FILE_NAME) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            
            pstmt.setString(1, profile.getName());
            pstmt.setString(2, profile.getStudentId());
            pstmt.setString(3, profile.getProgram());
            pstmt.setString(4, profile.getEmail());
            pstmt.setString(5, profile.getHobbies());
            pstmt.setString(6, profile.getIntroduction());
            pstmt.setString(7, profile.getPhotoFileName());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    int generatedId = rs.getInt(1);
                    System.out.println("Profile inserted successfully with ID: " + generatedId);
                    return generatedId;
                }
            }
            
            return -1;
        } catch (SQLException e) {
            System.err.println("✗✗✗ SQLException inserting profile:");
            System.err.println("SQL State: " + e.getSQLState());
            System.err.println("Error Code: " + e.getErrorCode());
            System.err.println("Message: " + e.getMessage());
            System.err.println("SQL: " + sql);

            if (e.getMessage() != null && e.getMessage().contains("does not exist")) {
                System.err.println("Attempting with schema-qualified table name (STUDENTADMIN.PROFILE)...");
                Connection schemaConn = null;
                PreparedStatement schemaPstmt = null;
                ResultSet schemaRs = null;
                try {
                    String schemaSQL = "INSERT INTO STUDENTADMIN.PROFILE (NAME, STUDENT_ID, PROGRAM, EMAIL, HOBBIES, INTRODUCTION, PHOTO_FILE_NAME) " +
                                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
                    schemaConn = DatabaseUtil.getConnection();
                    schemaPstmt = schemaConn.prepareStatement(schemaSQL, Statement.RETURN_GENERATED_KEYS);
                    schemaPstmt.setString(1, profile.getName());
                    schemaPstmt.setString(2, profile.getStudentId());
                    schemaPstmt.setString(3, profile.getProgram());
                    schemaPstmt.setString(4, profile.getEmail());
                    schemaPstmt.setString(5, profile.getHobbies());
                    schemaPstmt.setString(6, profile.getIntroduction());
                    schemaPstmt.setString(7, profile.getPhotoFileName());
                    
                    int rowsAffected = schemaPstmt.executeUpdate();
                    if (rowsAffected > 0) {
                        schemaRs = schemaPstmt.getGeneratedKeys();
                        if (schemaRs.next()) {
                            int generatedId = schemaRs.getInt(1);
                            System.out.println("✓ Profile inserted successfully with ID: " + generatedId + " (using STUDENTADMIN.PROFILE)");
                            closeResources(schemaConn, schemaPstmt, schemaRs);
                            return generatedId;
                        }
                    }
                    closeResources(schemaConn, schemaPstmt, schemaRs);
                } catch (SQLException schemaEx) {
                    System.err.println("Schema-qualified insert also failed: " + schemaEx.getMessage());
                    closeResources(schemaConn, schemaPstmt, schemaRs);
                }
            }
            
            e.printStackTrace();
            return -1;
        } catch (Exception e) {
            System.err.println("✗✗✗ Exception inserting profile:");
            System.err.println("Error: " + e.getMessage());
            System.err.println("Error class: " + e.getClass().getName());
            e.printStackTrace();
            return -1;
        } finally {
            closeResources(conn, pstmt, rs);
        }
    }
 
    public List<ProfileBean> getAllProfiles() {
        initializeTable();
        List<ProfileBean> profiles = new ArrayList<>();
        String sql = "SELECT * FROM PROFILE ORDER BY CREATED_AT DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                ProfileBean profile = mapResultSetToProfile(rs);
                profiles.add(profile);
            }
            
            System.out.println("Retrieved " + profiles.size() + " profiles from database");
        } catch (SQLException e) {
            System.err.println("Error retrieving profiles: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, rs);
        }
        
        return profiles;
    }
    
    public ProfileBean getProfileById(int id) {
        initializeTable();
        String sql = "SELECT * FROM PROFILE WHERE ID = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToProfile(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving profile by ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, rs);
        }
        
        return null;
    }

    public ProfileBean getProfileByStudentId(String studentId) {
        initializeTable();
        String sql = "SELECT * FROM PROFILE WHERE STUDENT_ID = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, studentId);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToProfile(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving profile by student ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, rs);
        }
        
        return null;
    }
    
    public List<ProfileBean> searchProfiles(String searchTerm) {
        initializeTable();
        List<ProfileBean> profiles = new ArrayList<>();
        String sql = "SELECT * FROM PROFILE WHERE NAME LIKE ? OR STUDENT_ID LIKE ? ORDER BY CREATED_AT DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            String searchPattern = "%" + searchTerm + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                ProfileBean profile = mapResultSetToProfile(rs);
                profiles.add(profile);
            }
            
            System.out.println("Found " + profiles.size() + " profiles matching: " + searchTerm);
        } catch (SQLException e) {
            System.err.println("Error searching profiles: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, rs);
        }
        
        return profiles;
    }
    
    public List<ProfileBean> filterByProgram(String program) {
        initializeTable();
        List<ProfileBean> profiles = new ArrayList<>();
        String sql = "SELECT * FROM PROFILE WHERE PROGRAM = ? ORDER BY CREATED_AT DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, program);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                ProfileBean profile = mapResultSetToProfile(rs);
                profiles.add(profile);
            }
        } catch (SQLException e) {
            System.err.println("Error filtering profiles by program: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, rs);
        }
        
        return profiles;
    }
    
    public List<ProfileBean> filterByHobby(String hobby) {
        initializeTable();
        List<ProfileBean> profiles = new ArrayList<>();
        String sql = "SELECT * FROM PROFILE WHERE HOBBIES LIKE ? ORDER BY CREATED_AT DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, "%" + hobby + "%");
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                ProfileBean profile = mapResultSetToProfile(rs);
                profiles.add(profile);
            }
        } catch (SQLException e) {
            System.err.println("Error filtering profiles by hobby: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, rs);
        }
        
        return profiles;
    }
    
    public boolean updateProfile(ProfileBean profile) {
        initializeTable();
        String sql = "UPDATE PROFILE SET NAME = ?, PROGRAM = ?, EMAIL = ?, HOBBIES = ?, " +
                     "INTRODUCTION = ?, PHOTO_FILE_NAME = ?, UPDATED_AT = CURRENT_TIMESTAMP WHERE ID = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            
            pstmt.setString(1, profile.getName());
            pstmt.setString(2, profile.getProgram());
            pstmt.setString(3, profile.getEmail());
            pstmt.setString(4, profile.getHobbies());
            pstmt.setString(5, profile.getIntroduction());
            pstmt.setString(6, profile.getPhotoFileName());
            pstmt.setInt(7, profile.getId());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("Profile updated successfully: ID " + profile.getId());
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error updating profile: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, null);
        }
        
        return false;
    }
    
    public boolean deleteProfile(int id) {
        initializeTable();
        String sql = "DELETE FROM PROFILE WHERE ID = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("Profile deleted successfully: ID " + id);
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error deleting profile: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, null);
        }
        
        return false;
    }

    private ProfileBean mapResultSetToProfile(ResultSet rs) throws SQLException {
        ProfileBean profile = new ProfileBean();
        profile.setId(rs.getInt("ID"));
        profile.setName(rs.getString("NAME"));
        profile.setStudentId(rs.getString("STUDENT_ID"));
        profile.setProgram(rs.getString("PROGRAM"));
        profile.setEmail(rs.getString("EMAIL"));
        profile.setHobbies(rs.getString("HOBBIES"));
        profile.setIntroduction(rs.getString("INTRODUCTION"));
        profile.setPhotoFileName(rs.getString("PHOTO_FILE_NAME"));
        
        Timestamp createdAt = rs.getTimestamp("CREATED_AT");
        if (createdAt != null) {
            profile.setCreatedAt(createdAt.toString());
        }
        
        Timestamp updatedAt = rs.getTimestamp("UPDATED_AT");
        if (updatedAt != null) {
            profile.setUpdatedAt(updatedAt.toString());
        }
        
        return profile;
    }

    private void closeResources(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) DatabaseUtil.closeConnection(conn);
        } catch (SQLException e) {
            System.err.println("Error closing resources: " + e.getMessage());
        }
    }
}


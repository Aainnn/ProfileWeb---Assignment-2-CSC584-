package com.profile.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtil {

    private static final String URL = "jdbc:derby://localhost:1527/StudentProfile";
    private static final String USER = "Studentadmin";
    private static final String PASSWORD = "root";
    
    static {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException e) {
            System.out.println("Error: Derby JDBC driver not found.");
            System.out.println("Make sure derbyclient.jar is in the project libraries.");
        }
    }

    public static Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        System.out.println("Connected to database: StudentProfile");
        return conn;
    }

    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.out.println("Warning: Error closing connection");
            }
        }
    }
}
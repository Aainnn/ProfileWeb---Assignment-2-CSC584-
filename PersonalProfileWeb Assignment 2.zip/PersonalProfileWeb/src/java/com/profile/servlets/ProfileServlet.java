package com.profile.servlets;

import com.profile.model.ProfileBean;
import com.profile.dao.ProfileDAO;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet(name = "ProfileServlet", urlPatterns = {"/ProfileServlet"})
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 1, // 1 MB
    maxFileSize = 1024 * 1024 * 5,      // 5 MB
    maxRequestSize = 1024 * 1024 * 50   // 50 MB
)
public class ProfileServlet extends HttpServlet {
    
    private ProfileDAO profileDAO;
    
    @Override
    public void init() throws ServletException {
        super.init();
        profileDAO = new ProfileDAO();
    }

    private String getFileExtension(String fileName) {
        if (fileName == null) return "";
        int lastIndex = fileName.lastIndexOf(".");
        if (lastIndex == -1) return "";
        return fileName.substring(lastIndex);
    }

    private String getSubmittedFileName(Part part) {
        for (String cd : part.getHeader("content-disposition").split(";")) {
            if (cd.trim().startsWith("filename")) {
                String fileName = cd.substring(cd.indexOf('=') + 1).trim().replace("\"", "");
                return fileName.substring(fileName.lastIndexOf('/') + 1).substring(fileName.lastIndexOf('\\') + 1);
            }
        }
        return null;
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        System.out.println("=== ProfileServlet Started ===");
        
        String webRoot = getServletContext().getRealPath("/");
        if (webRoot == null) {
            webRoot = getServletContext().getRealPath("");
            if (webRoot == null) {
                webRoot = System.getProperty("user.dir");
            }
        }

        String uploadPath = webRoot.replace('/', File.separatorChar).replace('\\', File.separatorChar);
        if (!uploadPath.endsWith(File.separator)) {
            uploadPath += File.separator;
        }
        uploadPath += "uploads" + File.separator;
        
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            boolean created = uploadDir.mkdirs(); // Use mkdirs() to create parent directories if needed
            System.out.println("Created uploads directory: " + uploadPath + " (success: " + created + ")");
        } else {
            System.out.println("Uploads directory exists: " + uploadPath);
        }
        
        System.out.println("Web root: " + webRoot);
        System.out.println("Uploads physical path: " + uploadPath);
        System.out.println("Uploads web path: uploads/");

        try {
            String name = null;
            String studentId = null;
            String program = null;
            String email = null;
            String hobbies = null;
            String introduction = null;
            String savedPhotoFileName = null;
            
            Collection<Part> parts = request.getParts();
            System.out.println("Total parts received: " + parts.size());

            long timestamp = System.currentTimeMillis();
            
            for (Part part : parts) {
                String partName = part.getName();
                long partSize = part.getSize();
                System.out.println("Processing part: " + partName + ", size: " + partSize + ", content-type: " + part.getContentType());
                
                if (partName == null) {
                    System.out.println("Skipping part with null name");
                    continue;
                }
                
                String fileName = getSubmittedFileName(part);
                boolean isFile = (fileName != null && !fileName.isEmpty() && partSize > 0);
                
                if (!isFile && partSize == 0 && !partName.equals("photo")) {
                    System.out.println("Skipping empty part: " + partName);
                    continue;
                }
                
                if (partName.equals("photo") && isFile) {
                    System.out.println("File upload detected: " + fileName + ", size: " + partSize);
                    
                    if (partSize > 0) {
                        String fileExtension = getFileExtension(fileName);
                        String savedFileName = timestamp + "_" + 
                            (studentId != null ? studentId : "unknown") + fileExtension;
                        
                        File savedFile = new File(uploadDir, savedFileName);
                        try {
                            if (!uploadDir.exists()) {
                                boolean created = uploadDir.mkdirs();
                                System.out.println("Created uploads directory: " + uploadDir.getAbsolutePath() + " (success: " + created + ")");
                            }
                            
                            System.out.println("Attempting to save file to: " + savedFile.getAbsolutePath());
                            
                            try (InputStream input = part.getInputStream();
                                 OutputStream output = new FileOutputStream(savedFile)) {
                                
                                byte[] buffer = new byte[8192];
                                int bytesRead;
                                long totalBytes = 0;
                                
                                while ((bytesRead = input.read(buffer)) != -1) {
                                    output.write(buffer, 0, bytesRead);
                                    totalBytes += bytesRead;
                                }
                                
                                output.flush();
                                
                                System.out.println("✓ File copied successfully. Total bytes: " + totalBytes);
                            }
                            
                            if (savedFile.exists() && savedFile.length() > 0) {
                                savedPhotoFileName = savedFileName;
                                System.out.println("✓✓✓ SUCCESS: Saved photo: " + savedFileName);
                                System.out.println("  Absolute path: " + savedFile.getAbsolutePath());
                                System.out.println("  File size: " + savedFile.length() + " bytes");
                                System.out.println("  Web URL will be: uploads/" + savedFileName);
                                System.out.println("  Full web URL: " + request.getContextPath() + "/uploads/" + savedFileName);
                            } else {
                                System.out.println("✗✗✗ CRITICAL ERROR: File write succeeded but file NOT found!");
                                System.out.println("  Expected path: " + savedFile.getAbsolutePath());
                                System.out.println("  File exists: " + savedFile.exists());
                                if (savedFile.exists()) {
                                    System.out.println("  File size: " + savedFile.length() + " bytes");
                                }

                                File[] files = uploadDir.listFiles();
                                if (files != null) {
                                    System.out.println("  Files in upload directory (" + uploadDir.getAbsolutePath() + "):");
                                    for (File f : files) {
                                        System.out.println("    - " + f.getName() + " (" + f.length() + " bytes)");
                                    }
                                }
                            }
                        } catch (Exception e) {
                            System.out.println("✗✗✗ ERROR saving file: " + e.getMessage());
                            System.out.println("  Exception type: " + e.getClass().getName());
                            e.printStackTrace();
                            if (savedFile.exists()) {
                                savedFile.delete();
                            }
                        }
                    }
                } else if (!partName.equals("photo")) {
                    System.out.println("Parsing text field: " + partName);
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(part.getInputStream(), "UTF-8"))) {
                        StringBuilder value = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            if (value.length() > 0) value.append("\n");
                            value.append(line);
                        }
                        String partValue = value.toString().trim();
                        
                        System.out.println("✓ Field " + partName + " = [" + partValue + "]");
                        
                        if ("name".equals(partName)) name = partValue;
                        else if ("studentId".equals(partName)) studentId = partValue;
                        else if ("program".equals(partName)) program = partValue;
                        else if ("email".equals(partName)) email = partValue;
                        else if ("hobbies".equals(partName)) hobbies = partValue;
                        else if ("introduction".equals(partName)) introduction = partValue;
                    } catch (Exception e) {
                        System.out.println("✗ Error reading text field " + partName + ": " + e.getMessage());
                        e.printStackTrace();
                    }
                }
            }

            System.out.println("=== FORM DATA RECEIVED ===");
            System.out.println("Name: " + name);
            System.out.println("Student ID: " + studentId);
            System.out.println("Program: " + program);
            System.out.println("Email: " + email);
            System.out.println("Hobbies: " + hobbies);
            System.out.println("Introduction: " + introduction);
            
            if (name == null || name.trim().isEmpty() ||
                studentId == null || studentId.trim().isEmpty()) {
                System.out.println("Validation failed - redirecting to index.html");
                response.sendRedirect("index.html");
                return;
            }

            System.out.println("Processing profile for: " + name + " (" + studentId + ")");
            
            // Create ProfileBean object
            ProfileBean profile = new ProfileBean();
            profile.setName(name);
            profile.setStudentId(studentId);
            profile.setProgram(program);
            profile.setEmail(email);
            profile.setHobbies(hobbies);
            profile.setIntroduction(introduction);
            profile.setPhotoFileName(savedPhotoFileName);

            // Insert profile into database using JDBC
            int profileId = -1;
            try {
                profileId = profileDAO.insertProfile(profile);
                
                if (profileId > 0) {
                    profile.setId(profileId);
                    System.out.println("✓ Profile saved to database with ID: " + profileId);
                } else {
                    System.out.println("✗ Failed to save profile to database - insertProfile returned -1");
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                        "Failed to save profile to database. Check server logs for details.");
                    return;
                }
            } catch (Exception e) {
                System.err.println("✗✗✗ EXCEPTION in ProfileServlet when saving to database:");
                System.err.println("Error: " + e.getMessage());
                System.err.println("Error class: " + e.getClass().getName());
                e.printStackTrace();
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                    "Database error: " + e.getMessage() + ". Check server console for details.");
                return;
            }

            List<ProfileBean> allProfiles = profileDAO.getAllProfiles();
            int profileCount = allProfiles.size();

            request.setAttribute("profile", profile);
            request.setAttribute("name", name);
            request.setAttribute("studentId", studentId);
            request.setAttribute("program", program);
            request.setAttribute("email", email);
            request.setAttribute("hobbies", hobbies);
            request.setAttribute("introduction", introduction);
            request.setAttribute("photoFileName", savedPhotoFileName);
            request.setAttribute("profileId", profileId);
            request.setAttribute("profileCount", profileCount);

            System.out.println("=== PHOTO FILE BEING PASSED TO JSP ===");
            System.out.println("photoFileName: " + savedPhotoFileName);
            if (savedPhotoFileName != null) {
                System.out.println("  Web URL: uploads/" + savedPhotoFileName);
                File testFile = new File(uploadPath + savedPhotoFileName);
                System.out.println("  File exists: " + testFile.exists());
                if (testFile.exists()) {
                    System.out.println("  File size: " + testFile.length() + " bytes");
                }
            }

            System.out.println("=== ATTRIBUTES SET ===");
            System.out.println("name: " + name);
            System.out.println("studentId: " + studentId);
            System.out.println("program: " + program);
            System.out.println("email: " + email);
            System.out.println("hobbies: " + hobbies);
            System.out.println("introduction: " + introduction);
            System.out.println("photoFileName: " + savedPhotoFileName);
            System.out.println("profileCount: " + profileCount);
            System.out.println("Forwarding to profile.jsp");

            RequestDispatcher dispatcher = request.getRequestDispatcher("profile.jsp");
            if (dispatcher == null) {
                System.out.println("✗ ERROR: RequestDispatcher is null for profile.jsp");
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                    "Cannot forward to profile.jsp");
                return;
            }
            
            System.out.println("✓ Forwarding request to profile.jsp...");
            dispatcher.forward(request, response);
            System.out.println("✓ Forward completed");
            
        } catch (IllegalStateException e) {
            System.out.println("✗ IllegalStateException in ProfileServlet (multipart already processed?): " + e.getMessage());
            e.printStackTrace();
            try {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                    "Error processing form: " + e.getMessage());
            } catch (Exception ex) {
                response.sendRedirect("index.html");
            }
        } catch (ServletException e) {
            System.out.println("✗ ServletException in ProfileServlet: " + e.getMessage());
            e.printStackTrace();
            try {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                    "Server error: " + e.getMessage());
            } catch (Exception ex) {
                response.sendRedirect("index.html");
            }
        } catch (Exception e) {
            System.out.println("✗ Unexpected Error in ProfileServlet: " + e.getMessage());
            System.out.println("Error class: " + e.getClass().getName());
            e.printStackTrace();
            try {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                    "Unexpected error: " + e.getMessage());
            } catch (Exception ex) {
                response.sendRedirect("index.html");
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("=== doPost called ===");
        processRequest(request, response);
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("=== doGet called - redirecting to index ===");
        response.sendRedirect("index.html");
    }
    
    @Override
    public String getServletInfo() {
        return "Personal Profile Servlet with Multiple Photo Upload";
    }
}
package com.profile.servlets;

import com.profile.model.ProfileBean;
import com.profile.dao.ProfileDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "EditProfileServlet", urlPatterns = {"/EditProfileServlet"})
public class EditProfileServlet extends HttpServlet {
    
    private ProfileDAO profileDAO;
    
    @Override
    public void init() throws ServletException {
        super.init();
        profileDAO = new ProfileDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String idParam = request.getParameter("id");
        
        if (idParam == null || idParam.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Profile ID is required");
            return;
        }
        
        try {
            int profileId = Integer.parseInt(idParam);
            ProfileBean profile = profileDAO.getProfileById(profileId);
            
            if (profile == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Profile not found");
                return;
            }
            
            request.setAttribute("profile", profile);
            request.getRequestDispatcher("editProfile.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid profile ID");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String idParam = request.getParameter("id");
        
        if (idParam == null || idParam.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Profile ID is required");
            return;
        }
        
        try {
            int profileId = Integer.parseInt(idParam);

            ProfileBean existingProfile = profileDAO.getProfileById(profileId);
            if (existingProfile == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Profile not found");
                return;
            }

            String name = request.getParameter("name");
            String program = request.getParameter("program");
            String email = request.getParameter("email");
            String hobbies = request.getParameter("hobbies");
            String introduction = request.getParameter("introduction");
            String photoFileName = request.getParameter("photoFileName");
            
            // Validate required fields
            if (name == null || name.trim().isEmpty()) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Name is required");
                return;
            }

            ProfileBean profile = new ProfileBean();
            profile.setId(profileId);
            profile.setName(name);
            profile.setStudentId(existingProfile.getStudentId()); // Preserve student ID
            profile.setProgram(program);
            profile.setEmail(email);
            profile.setHobbies(hobbies);
            profile.setIntroduction(introduction);
            profile.setPhotoFileName(photoFileName != null ? photoFileName : existingProfile.getPhotoFileName());
            
            boolean updated = profileDAO.updateProfile(profile);
            
            if (updated) {
                response.sendRedirect("viewProfiles.jsp");
            } else {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                    "Failed to update profile");
            }
            
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid profile ID");
        }
    }
}


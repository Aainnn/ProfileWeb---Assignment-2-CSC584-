package com.profile.servlets;

import com.profile.model.ProfileBean;
import com.profile.dao.ProfileDAO;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet(name = "ProfileListServlet", urlPatterns = {"/ProfileListServlet"})
public class ProfileListServlet extends HttpServlet {
    
    private ProfileDAO profileDAO;
    
    @Override
    public void init() throws ServletException {
        super.init();
        profileDAO = new ProfileDAO();
        System.out.println("ProfileListServlet initialized with ProfileDAO");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        System.out.println("=== ProfileListServlet Accessed ===");
        
        try {
            // Fetch profiles from database using ProfileDAO
            List<ProfileBean> profiles = profileDAO.getAllProfiles();
            
            System.out.println("Retrieved " + (profiles != null ? profiles.size() : 0) + " profiles from database");
            
            if (profiles == null) {
                profiles = new ArrayList<>();
                System.out.println("Created new empty profiles list");
            }
            
            request.setAttribute("profiles", profiles);
            
            System.out.println("Forwarding to viewProfiles.jsp");

            RequestDispatcher dispatcher = request.getRequestDispatcher("viewProfiles.jsp");
            dispatcher.forward(request, response);
            
        } catch (Exception e) {
            System.err.println("✗✗✗ Error in ProfileListServlet:");
            System.err.println("Error: " + e.getMessage());
            System.err.println("Error class: " + e.getClass().getName());
            e.printStackTrace();
            response.sendRedirect("index.html");
        }
    }
}